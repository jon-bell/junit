package org.catid.pipes;

public abstract class PipeListener {
	// Notifies when pipe is ready for connections
	public abstract void onPipeReady();

	// Notifies when pipe becomes connected
	public abstract void onPipeConnect();

	// Notifies when pipe becomes disconnected
	public abstract void onPipeDisconnect();

	// Notifies of message receipt
	public abstract void onPipeMessage(byte[] buffer);
}
