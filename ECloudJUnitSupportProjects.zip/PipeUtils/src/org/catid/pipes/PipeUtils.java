package org.catid.pipes;

public final class PipeUtils
{
	private static String OS = null;

	public static String getOsName() {
		if (OS == null) {
			OS = System.getProperty("os.name");
		}

		return OS;
	}

	public static boolean isWindows() {
		return getOsName().startsWith("Windows");
	}

	static {
		System.loadLibrary("pipeutils");
	}

	// On Windows, this code automatically prefixes the pipe with the Windows pipe prefix
	final static String WINDOWS_PIPE_PREFIX = "\\\\.\\pipe\\";

	public static String manglePipeName(String pipeName) {
		if (isWindows()) {
			return WINDOWS_PIPE_PREFIX + pipeName;
		} else {
			return pipeName;
		}
	}

	/*
	 * This is the Windows interface for pipes:
	 *
	 * The server calls createAndConnect(), which blocks until a connection
	 * is established with a client.  It returns a non-zero ptr on success or
	 * 0 on failure.  Failure can be interpreted to mean another server
	 * is already listening on the named pipe.
	 *
	 * When finished, call the closeConnectedPipe() function with same object
	 * returned by the Connect function described above.  Passing in 0 is okay.
	 *
	 * The client side calls waitNamedPipe() to wait for the server to become
	 * available.  It may return failure if the pipe is unavailable for some reason.
	 * Failure can be interpreted as there being another client already on the pipe.
	 * Returns true on success, false on failure.
	 */

	// Server interface
	public static native long createAndConnectNamedPipe(String name);
	public static native void closeConnectedPipe(long ptr);

	// Client interface
	public static native long openNamedPipe(String name);
	public static native void closeOpenedPipe(long ptr);

	// Shared interface
	public static native boolean readPipe(long ptr, byte[] buffer, int len);
	public static native boolean writePipe(long ptr, byte[] buffer);
}
