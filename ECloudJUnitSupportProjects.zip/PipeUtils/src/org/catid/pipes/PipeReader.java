package org.catid.pipes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class PipeReader extends Thread {
	String requestPipeName, responsePipeName;
	boolean isServer, isOpen, isConnected;
	PipeListener listener;
	long pipeHandle;

	byte[] marker = new byte[] {
		(byte) 254, (byte) 253
	};

	public PipeReader(String pipeName, PipeListener listener, boolean isServer) {
		super("PipeReader");

		this.requestPipeName = PipeUtils.manglePipeName(pipeName + "REQUEST");
		this.responsePipeName = PipeUtils.manglePipeName(pipeName + "RESPONSE");
		this.listener = listener;
		this.isServer = isServer;
	}

	public void open() {
		isOpen = true;

		start();
	}

	public boolean connected() {
		return isConnected;
	}
	
    public void close() {
    	System.out.println("PipeReader: Closing...");

    	isOpen = false;

    	closeNativePipe();

    	System.out.println("PipeReader: Closing request is in...");
    }

    private byte[] byteBuffer = new byte[1];
    private byte[] intBuffer = new byte[4];

    private byte readByte() throws IOException {
		if (!PipeUtils.readPipe(pipeHandle, byteBuffer, 1)) {
			throw new IOException("Broken pipe");
		}

		return byteBuffer[0];
    }

    private int readInt() throws IOException {
		if (!PipeUtils.readPipe(pipeHandle, intBuffer, 4)) {
			throw new IOException("Broken pipe");
		}

		return byteArrayToInt(intBuffer);
    }

    public static int byteArrayToInt(byte[] b) {
        return   b[3] & 0xFF |
                (b[2] & 0xFF) << 8 |
                (b[1] & 0xFF) << 16 |
                (b[0] & 0xFF) << 24;
    }

    public static void intToByteArray(int a, byte[] buffer) {
    	buffer[0] = (byte)(a >> 24);
    	buffer[1] = (byte)(a >> 16);
    	buffer[2] = (byte)(a >> 8);
    	buffer[3] = (byte)a;
    }

    private boolean waitForStartMarker() {
		try {
			for (;;) {
				System.out.println("-(marker)-> Reading first byte...");
				byte ch = readByte();

				System.out.println("-(marker)-> It was " + (int)ch);

				if (ch == -2) {
					System.out.println("-(marker)-> Got 254!  Reading second byte...");
					ch = readByte();

					System.out.println("-(marker)-> It was " + (int)ch);

					if (ch == -3) {
						return true;
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return false;
    }
    
	final static int MaxReadLength = 1000000; // 1 MB

	private boolean setupPipe() {
		if (isServer) {
			pipeHandle = PipeUtils.createAndConnectNamedPipe(requestPipeName);

			return pipeHandle != 0;
		} else {
			pipeHandle = PipeUtils.openNamedPipe(requestPipeName);

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			return pipeHandle != 0;
		}
	}

	private void closeNativePipe() {
		if (PipeUtils.isWindows()) {
			PipeUtils.closeConnectedPipe(pipeHandle);
			pipeHandle = 0;
		}
	}
	
    public void run() {
		System.out.println(">>> PipeReader is starting");

		listener.onPipeReady();

		while (isOpen) {
			System.out.println("+ Setting up pipe...");

			if (!setupPipe()) {
				System.out.println("+ Failed to set up pipe, retrying...");

				closeNativePipe();

				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				continue;
			}

			if (!isOpen) {
				System.out.println("+ Pipe setup step finished.  But closing, so shutting down now...");

		    	closeNativePipe();
				break;
			}

			System.out.println("+ Pipe setup step finished.");

			isConnected = true;
			listener.onPipeConnect();

			try {
				System.out.println("+ Waiting for start marker.");

				while (waitForStartMarker()) {
					int len = readInt();

					System.out.println("Got start marker and length = " + len);

					if (len < MaxReadLength) {
						byte[] buffer = new byte[len];

						PipeUtils.readPipe(pipeHandle, buffer, len);

						listener.onPipeMessage(buffer);
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			isConnected = false;
			listener.onPipeDisconnect();

	    	closeNativePipe();
		}

		System.out.println("<<< PipeReader is terminating");
    }

    public boolean writeMessage(byte[] buffer) {
    	try {
    		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    		outputStream.write(marker);
    		intToByteArray(buffer.length, intBuffer);
    		outputStream.write(intBuffer);
    		outputStream.write(buffer);

    		byte[] outBuffer = outputStream.toByteArray();

    		System.out.println("+ Writing message with length = " + buffer.length + " output buffer = " + outBuffer.length + " bytes.  First byte is " + buffer[0]);

    		PipeUtils.writePipe(pipeHandle, outBuffer);

    		System.out.println("+ Done writing");
    	} catch (IOException e) {
			e.printStackTrace();
			return false;
		}

    	return true;
    }
}
