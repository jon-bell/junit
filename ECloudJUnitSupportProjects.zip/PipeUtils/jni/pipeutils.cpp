#include "org_catid_pipes_PipeUtils.h"

#define WINVER 0x0602
#define _WIN32_WINNT 0x0602

#include <windows.h>
#include <stdint.h>
#include <stdio.h>

#ifndef JNICALL
#define JNICALL
#endif

#ifndef JNI_TRUE
#define JNI_TRUE 1
#endif

#ifndef JNI_FALSE
#define JNI_FALSE 0
#endif


/** Obtains the SID of the user running this thread or process.
Output parameters: ppSidUser: the SID of the current user,
TRUE   | FALSE: could not obtain the user SID */
BOOL
    GetUserSid( PSID*  ppSidUser )
{
    HANDLE      hToken;
    DWORD       dwLength;
    DWORD       cbName = 250;
    DWORD       cbDomainName = 250;

    if( !OpenThreadToken( GetCurrentThread(), TOKEN_QUERY, TRUE, &hToken) )
    {
        if( GetLastError() == ERROR_NO_TOKEN )
        {
            if( !OpenProcessToken( GetCurrentProcess(), TOKEN_QUERY, &hToken) )
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }

    PTOKEN_USER pTokenUser = 0;

    if( !GetTokenInformation( hToken,       // handle of the access token
                              TokenUser,    // type of information to retrieve
                              0,   // address of retrieved information
                              0,            // size of the information buffer
                              &dwLength     // address of required buffer size
                              ))
    {
        if( GetLastError() == ERROR_INSUFFICIENT_BUFFER )
        {
            pTokenUser = (PTOKEN_USER) HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, dwLength );
            if( pTokenUser == NULL )
            {
                return FALSE;
            }
        }
        else
        {
            return FALSE;
        }
    }

    if( !GetTokenInformation(   hToken,     // handle of the access token
                                TokenUser,  // type of information to retrieve
                                pTokenUser, // address of retrieved information
                                dwLength,   // size of the information buffer
                                &dwLength   // address of required buffer size
                                ))
    {
        HeapFree( GetProcessHeap(), 0, pTokenUser );
        pTokenUser = NULL;

        return FALSE;
    }

    *ppSidUser = pTokenUser->User.Sid;
    return TRUE;
}

/** Builds security attributes that allows read-only access to everyone
Input parameters: psa: security attributes to build
Output parameters: TRUE | FALSE */
BOOL
    BuildSecurityAttributes( SECURITY_ATTRIBUTES* psa )
{
    DWORD dwAclSize;
    PSID  pSidAnonymous = NULL; // Well-known AnonymousLogin SID
    PSID  pSidOwner = NULL;

    SID_IDENTIFIER_AUTHORITY siaAnonymous = SECURITY_NT_AUTHORITY;
    SID_IDENTIFIER_AUTHORITY siaOwner = SECURITY_NT_AUTHORITY;

    {
    	PSECURITY_DESCRIPTOR psd = (PSECURITY_DESCRIPTOR) HeapAlloc( GetProcessHeap(),
                                                HEAP_ZERO_MEMORY,
                                                SECURITY_DESCRIPTOR_MIN_LENGTH);
        if( psd == NULL )
        {
        	return false;
        }

        if( !InitializeSecurityDescriptor( psd, SECURITY_DESCRIPTOR_REVISION) )
        {
        	return false;
        }

        // Build anonymous SID
        AllocateAndInitializeSid( &siaAnonymous, 1,
                                  SECURITY_ANONYMOUS_LOGON_RID,
                                  0,0,0,0,0,0,0,
                                  &pSidAnonymous
                                );

        if( !GetUserSid( &pSidOwner ) )
        {
            return false;
        }

        // Compute size of ACL
        dwAclSize = sizeof(ACL) +
                    2 * ( sizeof(ACCESS_ALLOWED_ACE) - sizeof(DWORD) ) +
                    GetLengthSid( pSidAnonymous ) +
                    GetLengthSid( pSidOwner );

        PACL pACL = (PACL)HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, dwAclSize );
        if( pACL == NULL )
        {
            return false;
        }

        InitializeAcl( pACL, dwAclSize, ACL_REVISION);

        if( !AddAccessAllowedAce( pACL,
                                  ACL_REVISION,
                                  GENERIC_ALL,
                                  pSidOwner
                                ))
        {
            return false;
        }

        if( !AddAccessAllowedAce( pACL,
                                  ACL_REVISION,
                                  FILE_GENERIC_READ, //GENERIC_READ | GENERIC_WRITE,
                                  pSidAnonymous
                                ) )
        {
            return false;
        }

        if( !SetSecurityDescriptorDacl( psd, TRUE, pACL, FALSE) )
        {
            return false;
        }

        psa->nLength = sizeof(SECURITY_ATTRIBUTES);
        psa->bInheritHandle = TRUE;
        psa->lpSecurityDescriptor = psd;
    }

    if( pSidAnonymous )   FreeSid( pSidAnonymous );
    //if( pSidOwner )       FreeSid( pSidOwner );

    return true;
}



struct PipeInternal {
	HANDLE hPipe;
};




/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    createAndConnectNamedPipe
 * Signature: (Ljava/lang/String;)Z
 */
JNIEXPORT jlong JNICALL Java_org_catid_pipes_PipeUtils_createAndConnectNamedPipe
	(JNIEnv *env, jclass clazz, jstring nameJava)
{
	jlong rval = 0;

	const char *name = env->GetStringUTFChars(nameJava, 0);

	printf("Building security attributes %s\n", name);

	SECURITY_ATTRIBUTES sa;
	BuildSecurityAttributes(&sa);

	HANDLE hPipe = CreateNamedPipe(
			  name,
			  PIPE_ACCESS_DUPLEX,
			  PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
			  PIPE_UNLIMITED_INSTANCES,
			  4096,
			  4096,
			  0,
			  &sa);

	printf("PipeUtils: Create named pipe %s -> %p\n", name, hPipe);
	fflush(stdout);

	// If pipe was created successfully,
	if (hPipe != INVALID_HANDLE_VALUE) {
		// Wait here until the pipe connects
		if (0 != ConnectNamedPipe(hPipe, NULL)) {
			printf("PipeUtils: Pipe %p connected to client!\n", hPipe);
			fflush(stdout);

			// Store native pipe data
			PipeInternal *internal = new PipeInternal;
			internal->hPipe = hPipe;

			// Use temporary space to avoid 32-bit pointer issues
			int64_t bval = (int64_t)internal;
			rval = *((jlong*)&bval);
		} else {
			printf("PipeUtils: Pipe %p failed to connect to client.\n", hPipe);
			fflush(stdout);

			CloseHandle(hPipe);
		}
	}

	env->ReleaseStringUTFChars(nameJava, name);

	return rval;
}

/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    readPipe
 * Signature: (J[BI)Z
 */
JNIEXPORT jboolean JNICALL Java_org_catid_pipes_PipeUtils_readPipe
  (JNIEnv *env, jclass clazz, jlong ptr, jbyteArray byteArray, jint len)
{
	if (ptr != 0) {
		PipeInternal *internal = *((PipeInternal**)&ptr);

		jboolean isCopy;
		jbyte *body = env->GetByteArrayElements(byteArray, &isCopy);
		DWORD bytesRead = len;

		printf("PipeUtils: Reading %d bytes from %p\n", len, internal->hPipe);
		fflush(stdout);

		if (ReadFile(internal->hPipe, body, len, &bytesRead, NULL))
		{
			printf("PipeUtils: Got %d actual bytes.  First one was %d\n", bytesRead, (int)*body);
			fflush(stdout);

			if (bytesRead == len) {
				env->ReleaseByteArrayElements(byteArray, body, JNI_COMMIT);
				return JNI_TRUE;
			}
		}

		env->ReleaseByteArrayElements(byteArray, body, JNI_ABORT);
	}

	printf("PipeUtils: Failed to read %d\n", GetLastError());
	fflush(stdout);

	return JNI_FALSE;
}

/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    writePipe
 * Signature: (J[B)Z
 */
JNIEXPORT jboolean JNICALL Java_org_catid_pipes_PipeUtils_writePipe
  (JNIEnv *env, jclass clazz, jlong ptr, jbyteArray byteArray)
{
	if (ptr) {
		PipeInternal *internal = *((PipeInternal**)&ptr);

		jboolean isCopy;
		jbyte *body = env->GetByteArrayElements(byteArray, &isCopy);
		jsize len = env->GetArrayLength(byteArray);
		DWORD bytesRead = len;

		printf("PipeUtils: Writing %d bytes to %p\n", len, internal->hPipe);
		fflush(stdout);

		if (WriteFile(internal->hPipe, body, len, &bytesRead, NULL))
		{
			printf("PipeUtils: Wrote %d actual bytes\n", bytesRead);
			fflush(stdout);

			if (bytesRead == len) {
				return JNI_TRUE;
			}
		}
	}

	printf("PipeUtils: Failed to write %d\n", GetLastError());
	fflush(stdout);

	return JNI_FALSE;
}

/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    closeConnectedPipe
 * Signature: (Ljava/nio/ByteBuffer;)V
 */
JNIEXPORT void JNICALL Java_org_catid_pipes_PipeUtils_closeConnectedPipe
  (JNIEnv *env, jclass clazz, jlong ptr)
{
	if (ptr) {
		PipeInternal *internal = *((PipeInternal**)&ptr);

		HANDLE hPipe = internal->hPipe;

		if (INVALID_HANDLE_VALUE != hPipe) {
			CancelIoEx(hPipe, NULL);

			printf("PipeUtils: Disconnecting named pipe...\n");
			fflush(stdout);

			DisconnectNamedPipe(hPipe);

			printf("PipeUtils: Closing named pipe handle...\n");
			fflush(stdout);

			CloseHandle(hPipe);
		}

		delete internal;
	}

	printf("PipeUtils: End of closeConnectedPipe %d\n", GetLastError());
	fflush(stdout);
}

/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    openNamedPipe
 * Signature: (Ljava/lang/String;)J
 */
JNIEXPORT jlong JNICALL Java_org_catid_pipes_PipeUtils_openNamedPipe
  (JNIEnv *env, jclass clazz, jstring nameJava)
{
	jlong rval = 0;

	const char *name = env->GetStringUTFChars(nameJava, 0);

	HANDLE hPipe =  hPipe = CreateFile(
	         name,   // pipe name
	         GENERIC_READ |  // read and write access
	         GENERIC_WRITE,
	         0,              // no sharing
	         NULL,           // default security attributes
	         OPEN_EXISTING,  // opens existing pipe
	         0,              // default attributes
	         NULL);          // no template file

	printf("PipeUtils: Open named pipe %s -> %p\n", name, hPipe);
	fflush(stdout);

	// If pipe was created successfully,
	if (hPipe != INVALID_HANDLE_VALUE) {
		DWORD dwMode = PIPE_WAIT | PIPE_READMODE_BYTE | PIPE_TYPE_BYTE
				| PIPE_ACCEPT_REMOTE_CLIENTS;
		if (SetNamedPipeHandleState(hPipe,    // pipe handle
				&dwMode,  // new pipe mode
				NULL,     // don't set maximum bytes
				NULL)) {
			// Store native pipe data
			PipeInternal *internal = new PipeInternal;
			internal->hPipe = hPipe;

			// Use temporary space to avoid 32-bit pointer issues
			int64_t bval = (int64_t) internal;
			rval = *((jlong*) &bval);
		} else {
			printf("PipeUtils: Client failed to set mode of pipe %d.\n",
					GetLastError());
			fflush(stdout);

			CloseHandle(hPipe);
		}
	} else if (GetLastError() == ERROR_PIPE_BUSY) {
		// Wait for pipe to become available
		if (0 != WaitNamedPipe(name, NMPWAIT_WAIT_FOREVER)) {
			printf("PipeUtils: Client found server pipe!\n");
			fflush(stdout);
		} else {
			printf("PipeUtils: Client failed to find server pipe.\n");
			fflush(stdout);
		}
	}

	env->ReleaseStringUTFChars(nameJava, name);

	return rval;
}

/*
 * Class:     org_catid_pipes_PipeUtils
 * Method:    closeOpenedPipe
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_org_catid_pipes_PipeUtils_closeOpenedPipe
  (JNIEnv *env, jclass clazz, jlong ptr)
{
	if (ptr) {
		PipeInternal *internal = *((PipeInternal**)&ptr);

		HANDLE hPipe = internal->hPipe;

		if (INVALID_HANDLE_VALUE != hPipe) {
			CancelIoEx(hPipe, NULL);

			printf("PipeUtils: Closing opened named pipe handle...\n");
			fflush(stdout);

			CloseHandle(hPipe);
		}

		delete internal;
	}

	printf("PipeUtils: End of closeOpenedPipe %d\n", GetLastError());
	fflush(stdout);
}
