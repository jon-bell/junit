import static org.junit.Assert.assertEquals;

public class JunitTest {
	public boolean testRandomFeature() {
		System.out.println("Executing testRandomFeature\n");

		//return Math.random() > 0.5;
		return false;
	}
}
