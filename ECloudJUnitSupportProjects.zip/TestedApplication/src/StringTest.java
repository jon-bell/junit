import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * 
 */

/**
 * @author catid
 *
 */
public class StringTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.print("Executing setUpBeforeClass\n");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.print("Executing tearDownAfterClass\n");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		System.out.print("Executing setUp\n");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		System.out.print("Executing tearDown\n");
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature2() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature3() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature4() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature5() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature6() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature7() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature8() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature9() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

	/**
	 * Test method for {@link JunitTest#testRandomFeature()}.
	 */
	@Test
	public final void testTestRandomFeature10() {
		System.out.print("Executing test for TestRandomFeature\n");

		JunitTest tester = new JunitTest();

		assertTrue(tester.testRandomFeature());
	}

}
